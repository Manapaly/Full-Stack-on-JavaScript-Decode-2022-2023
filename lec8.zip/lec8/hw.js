// let a = 1, b = 3
// if(a <= 1 && b >= 3) console.log(a + b)
// else console.log(a - b)

// let num = 16
// if(num <= 14) console.log("pervaya")
// else if(num <= 29) console.log("vtoraya")
// else if(num <= 44) console.log("tretia")
// else if(num <= 59) console.log("chetveratya")

// let a = 100, b = 500, c = 1000
// let mn, mx
// if(a >= b && a >= c) mx = a
// else if(b >= a && b >= c) mx = b
// else if(c >= a && c >= b) mx = c
// if(a <= b && a<= c) mn = a
// else if(b <= a && b <= c) mn = b
// else if(c <=a && c <= b) mn = c
// console.log(mx - mn)


// let a = 6, b = 10
// if(a % 2 == 0 && b % 2 == 0) console.log((a*b)*(a*b))
// else if(a % 2 == 0 || b % 2 == 0) console.log((a/b)+(a*b))
// else if(a % 2 == 1 && b % 2 == 1) console.log(a + b)

// let a = 6, b = 10, c = 30
// let mx
// if(a >= b && a >= c) mx = a
// else if(b >= a && b >= c) mx = b
// else if(c >= a && c >= b) mx = c
// if(a <= b <= c){
//     a = mx
//     b = mx
//     c = mx
// }else if(a > b > c){
//     a = a*a
//     b = b*b
//     c = c*ca
// }
// console.log(a, b, c)

// const login = "admin", password = "secret"
// let log = prompt()
// let pass = prompt()
// if(log == login && pass == password) console.log("Вы успешно авторизировались")
// else if(log != login) console.login("Пользователя с данным логином не зарегистрирован")
// else if(log == login && pass != password) console.log("Вы неверно ввели пароль")

// let a = 10
// if(a == 5 || a == 10 || a == 14 || a == 100) a = a*a*a
// else a = Math.abs(a)
// console.log(a)

// let num = 121
// if(num % 11 == 0) num += 20
// else if( num >= 0 && num % 2 == 0) num -= 5
// else num = num*num
// console.log(num)

// let a = 100, b = 500, c = 1000
// let mn, mx
// if(a >= b && a >= c) mx = a
// else if(b >= a && b >= c) mx = b
// else if(c >= a && c >= b) mx = c
// if(a <= b && a<= c) mn = a
// else if(b <= a && b <= c) mn = b
// else if(c <=a && c <= b) mn = c
// if(a != mx && a != mn) console.log(a)
// else if(b != mx && b != mn) console.log(b)
// else if(c != mx && c != mn) console.log(c)

// let a = 100, b = 500, c = 1000
// let cnt1 = 0, cnt2 = 0
// if(a > 0) cnt1++
// else if(b > 0) cnt1++
// else if(c > 0) cnt1++
// if(a < 0) cnt2++
// else if(b < 0) cnt2++
// else if(c < 0) cnt2++

// let str = 'abcde'
// if(str[0]=='a') console.log('yes')
// else console.log('No')

// let str = '12345'
// if(str[0]=='1' || str[0]=='2' || str[0]=='3') console.log('yes')
// else console.log('No')