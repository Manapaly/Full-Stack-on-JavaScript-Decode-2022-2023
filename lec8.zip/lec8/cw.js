// let b = 15
// b % 2 == 0 ? console.log('Yes') : console.log("No") 

// let b = 15
// b >= 0 ? console.log('Yes') : console.log("No") 

// let b = 21
// b >= 18 ? console.log('Can') : console.log("Can not")

// let b = 135
// b >= 120 ? console.log('Проходит') : console.log("Не проходит")

// let a = 12, b = 25, c = 52
// let mx
// if(a >= b && a >= c) mx = a
// else if(b >= a && b >= c) mx = b
// else if(c >= a && c >= b) mx = c
// console.log(mx)

// let g = 42
// let output
// if(g < 0) output = 'Moroz'
// else if(g < 10) output = 'Ochenь holodno'
// else if(g < 20) output = 'Holodno'
// else if(g < 30) output = 'Norm'
// else if(g < 40) output = 'Zharko'
// else output = 'Ochen zharko'
// console.log(output)

// let a, b, c
// a = 40, b = 55, c = 65
// if(a + b + c == 180) console.log('Durys')
// else console.log('Kate')

// let ans = '@'
// let askiiOfChar = ans.charCodeAt(0)
// if(askiiOfChar >= 65 &&  askiiOfChar <= 90 || askiiOfChar >= 97 &&  askiiOfChar <= 122){
//     console.log('Это буква')
// }else{
//     console.log('Это не буква')
// }

// let ans = 'aeiouAEIOU'
// let ch = 'k'
// if(!ans.includes(ch)){
//     console.log('согласная')
// }else{
//     console.log('гласная')
// }

// let c = 'A'
// switch(c){
//     case 'E':
//         document.write('Excellent')
//         break
//     case 'V':
//         document.write('Very Good')
//         break
//     case 'G':                
//         document.write('Good')
//         break
    
//     case 'A':
//         document.write('Average')
//         break
//     case 'F':
//         document.write('Fail')
//         break
//     default:
//         document.write('error')
// }