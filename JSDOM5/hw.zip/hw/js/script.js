// console.log('ejsbfkj')
function createItem(_title, _description, _price, _availability){
    let card =document.createElement('div')

    let appTitle = document.createElement('h2')
    let appDescription = document.createElement('p')
    let appPrice = document.createElement('span')
    let appAvailability = document.createElement('div')
    let appDelete = document.createElement('button')
    let appBuy = document.createElement('button')

    card.classList.add('card')
    appTitle.classList.add('title')
    appDescription.classList.add('description')
    appPrice.classList.add('price')
    appAvailability.classList.add('availability')
    appDelete.classList.add('delete')
    appBuy.classList.add('buy')

    appTitle.innerHTML=_title
    appDescription.innerHTML=_description
    appPrice.innerHTML=_price
    appAvailability.innerHTML=_availability
    appDelete.innerHTML='X'
    appBuy.innerHTML='Buy now'

    appDelete.addEventListener("click", function() {
        this.parentNode.remove()
    });

    card.append(appTitle)
    card.append(appDescription)
    card.append(appPrice)
    card.append(appAvailability)
    card.append(appDelete)
    card.append(appBuy)
    return card
}

let localStorage = [
    {
        title: 'IPhone 14',
        description: 'IPhone 14 128Gb black' ,
        price: '100 000тг' ,
        isInStock: false
    },
    {
        title: 'Сумка',
        description: 'Сумка black' ,
        price: '10 000тг' ,
        isInStock: true
    },
    {
        title: 'Платье',
        description: 'Платье black M',
        price: '23 000' ,
        isInStock: false
    },
    {
        title: 'IPhone 14',
        description: 'IPhone 14 128Gb black' ,
        price: '100 000тг' ,
        isInStock: false
    },
    {
        title: 'Сумка',
        description: 'Сумка black' ,
        price: '10 000тг' ,
        isInStock: true
    },
    {
        title: 'IPhone 14',
        description: 'IPhone 14 128Gb black' ,
        price: '100 000тг' ,
        isInStock: false
    },
    {
        title: 'Сумка',
        description: 'Сумка black' ,
        price: '10 000тг' ,
        isInStock: true
    },
]

let cont = document.querySelector('.store');
console.log(cont)
function draw(){
    for (let i of localStorage){
        let availability = ''
        if(i.isInStock === false){
            availability = 'Нет в наличии'
        }else{
            availability = 'В наличии'
        }
        let card = createItem(i.title, i.description, i.price, availability)
        cont.appendChild(card)
    }
}


function deleteCard(del){
    del.parentNode.remove();
}

draw()