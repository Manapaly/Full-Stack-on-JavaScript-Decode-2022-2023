let menu = document.getElementById("menu")
function changeMenu(){
    menu.classList.toggle('open-menu')
}