// for(let i = 1; i <= 100; i++){
//     console.log(i)
// }

// for(let i = 11; i <= 33; i++){
//     console.log(i)
// }

// for(let i = 0; i <= 100; i++){
//     if(i % 2 == 0) console.log(i)
// }

// let sum = 0
// for(let i = 1; i <= 100; i++){
//     sum += i
// }
// console.log(sum)

// for(let i = 10; i <= 20; i++){
//     console.log(i*i)
// }

// let cnt1 = 0, cnt2 = 0
// for(let i = 24; i < 98; i++){
//     if(i % 2 == 0) cnt1++
//     else cnt2++
// }
// console.log(cnt1, cnt2)

let n = +prompt()
for(let i = 1; i <= 10; i++){
    console.log(n + ' x ' + i + ' = ' + n*i)
}