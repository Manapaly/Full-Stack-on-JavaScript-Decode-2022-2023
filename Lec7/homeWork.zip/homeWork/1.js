// let h, m, s
// h = 13
// m = 58
// s = 33
// alert(h + ':' + m + ':' + s)

// let a = 5
// let b = 4
// let temp
// temp = a
// a = b
// b = temp
// alert('b = ' + b + '\n' + 'a = ' + a)

// let str = 'abcde'
// alert(str[0] + ', ' +str[1] + ', ' + str[str.length - 1])

// let a = 3, b = 4
// let c = Math.pow(a, 2) + Math.pow(b, 2)
// alert(Math.sqrt(c))

// let age = 19
// alert(`Мне ${age} лет`)

// let name = prompt('Введите имя')
// alert(`Welcome ${name}`)

// let a, b, c
// alert(a - b - c)

// let a = +prompt('Введите первое число')
// let b = +prompt('Введите второе число')
// let c = +prompt('Введите третье число')
// a *= 2
// b -= 3
// c *= c
// alert(a + b + c)

// let t = 30
// let F = (9/5 * t)+32
// alert(F)

// let a = +prompt('Введите первое число')
// let b = +prompt('Введите второе число')
// let c = +prompt('Введите третье число')
// alert(a*a + 3 * Math.pow(b, 3) + 3*a*b + c*c)

