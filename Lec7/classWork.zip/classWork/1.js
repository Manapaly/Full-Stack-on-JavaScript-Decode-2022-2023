// document.write("Учу!")

// let name = 'Ernat'
// let surname = 'Manapaly'
// let age = 19

// let num = +prompt('Введите число')
// alert(Math.pow(num,2))15

// let num1, num2
// num1 = 15
// num2 = num1
// console.log(num2)

// let a = 3, b = 10, c = 9
// console.log(a*b*c)

// let a = 4, b = 2, c = 10
// console.log((a+b)/2 + (b+c)/2)

// let n = 4
// n += 25
// n /= 10
// n -= 12
// console.log(Math.pow(n, 2).toFixed(2))



